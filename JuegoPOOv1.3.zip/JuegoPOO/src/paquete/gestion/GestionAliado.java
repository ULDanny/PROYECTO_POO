/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paquete.gestion;

import paquete.clases.*;


public class GestionAliado {
    private Aliado[] arreglo;
    private int cont;

    public GestionAliado() {
        arreglo = new Aliado[3];
        cont = 0;
    }

    public Aliado[] getArreglo() {
        return arreglo;
    }

    public void setArreglo(Aliado[] arreglo) {
        this.arreglo = arreglo;
    }

    public int getCont() {
        return cont;
    }

    public void setCont(int cont) {
        this.cont = cont;
    }
    
    public void Agregar(Aliado ref){
        if(cont<arreglo.length){
            arreglo[cont]=ref;
            cont++;
        }else{
            System.out.println("No hay espacio");
        }
    }    
    
    
    
}
