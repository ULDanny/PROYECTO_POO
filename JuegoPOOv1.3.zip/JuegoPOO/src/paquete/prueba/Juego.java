/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paquete.prueba;

import java.util.Scanner;
import paquete.clases.*;
import paquete.gestion.*;


public class Juego {
  public static void main(String[] args) {
    int aux = 0;
    Scanner sc = new Scanner(System.in);
      System.out.println("====MATH ATTACK: REVENGE OF THE NUMBERS====");
      System.out.println("Bienvenido a nuestro videojuego. Para comenzar");
    System.out.println("Ingresa tu nombre: ");
    String nombre = sc.next();
    System.out.println("Ingresa el nivel inicial: ");
    int nivel = sc.nextInt();
    System.out.println("Opciones:\n"
              + "- Hechicero\n"
              + "- Arquero\n"
            + "- Guerrero");
    String eleccion = sc.next();
    Hechicero H1 = new Hechicero(nivel, nombre);
    Arquero A1 = new Arquero(nivel, nombre);
    Guerrero G1  = new Guerrero(nivel,nombre);
    GestionAliado tropa = new GestionAliado();
    int elec =0;
    tropa.Agregar(A1);
    tropa.Agregar(H1);
    tropa.Agregar(G1);
    String nm="";
    if (eleccion.equalsIgnoreCase("Hechicero")){
        elec =1;
        aux = elec;
        nm = "Hechicero";
    }
    else if(eleccion.equalsIgnoreCase("Arquero")){
        elec =0;
        aux = elec;
        nm = "Arquero";
    }else if(eleccion.equalsIgnoreCase("Guerrero")){
        elec=2;
        aux = elec;
        nm="Guerrero";
    }
    do{
    tropa.getArreglo()[elec].setNivel(nivel);
    tropa.getArreglo()[elec].setExpTotal(tropa.getArreglo()[aux].getExpTotal());
    System.out.println("NIVEL: " + nivel);
    tropa.getArreglo()[elec].CalcVida();
    System.out.println("Bienvenido " + nm + " " + nombre + ". Tu vida inicial es de " +  tropa.getArreglo()[elec].getVida());
    Enemigo E1 = new Enemigo(nivel, "Malo");
    E1.CalcVida();
    do{
      tropa.getArreglo()[elec].Ataque();
      E1.setVida(E1.getVida() - tropa.getArreglo()[elec].getAtaque());
      System.out.println("Tu ataque fue de " + tropa.getArreglo()[elec].getAtaque() + " daño");
      if (E1.getVida() > 0){
        System.out.println("El enemigo tiene " + E1.getVida() + " de vida");
        System.out.println("=====PRESIONA ENTER PARA CONTINUAR=====");
        sc.nextLine();
        E1.Ataque();
        tropa.getArreglo()[elec].setVida(tropa.getArreglo()[elec].getVida() - E1.getAtaque());
        System.out.println("El ataque del enemigo fue de " + E1.getAtaque() + " daño");
        System.out.println("Tienes " + tropa.getArreglo()[elec].getVida()+ " de vida");
          System.out.println("=====PRESIONA ENTER PARA CONTINUAR=====");
        sc.nextLine();
    }
    }while(E1.getVida() > 0 && tropa.getArreglo()[elec].getVida() > 0);
    if(tropa.getArreglo()[elec].getVida()<0){
      System.out.println("Tienes 0 de vida");
      System.out.println("Perdiste :(");
    }else if(E1.getVida()<0){
      System.out.println("El enemigo tiene 0 de vida");
      System.out.println("Ganaste! :)");
      nivel++;
    }
    tropa.getArreglo()[elec].CalcExp();
    if(tropa.getArreglo()[elec].getExpTotal() >= 100){
        System.out.println("Tienes la experiencia necesaria para poder cambiar de Personaje");
        System.out.println("¿Deseas cambiar? ¿Si o no?)");
        String a = sc.next();
        if(a.equalsIgnoreCase("Si")){
            System.out.println("Elige el personaje al que quieres cambiar");
            System.out.println("Opciones:\n"
              + "- Hechicero\n"
              + "- Arquero\n"
                    + "- Guerrero");
            eleccion = sc.next();
            if(eleccion.equalsIgnoreCase(nm)){
                System.out.println("El personaje elegido es el mismo");
            }else if(eleccion.equalsIgnoreCase("Hechicero")){
                System.out.println("Ha cambiado a Hechicero");
                nm = " Hechicero ";
                aux = elec;
                elec = 1;
                tropa.getArreglo()[aux].setExpTotal(tropa.getArreglo()[aux].getExpTotal()-100);
                
            }else if(eleccion.equalsIgnoreCase("Arquero")){
                aux = elec;
                elec =0;
                nm = " Arquero ";
                tropa.getArreglo()[aux].setExpTotal(tropa.getArreglo()[aux].getExpTotal()-100);
            }else if(eleccion.equalsIgnoreCase("Guerrero")){
                aux = elec;
                elec = 0;
                nm = "Guerrero";
                tropa.getArreglo()[aux].setExpTotal(tropa.getArreglo()[aux].getExpTotal()-100);
            }
        }else if(a.equalsIgnoreCase("No")){
            System.out.println("No hay cambio de personaje");
        }
    }
    }while(nivel<6);
}
}