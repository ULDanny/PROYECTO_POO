/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paquete.clases;

import java.util.Random;
import java.util.Scanner;


public class Hechicero extends Aliado{

    public Hechicero(int nivel, String nombre) {
        super(nivel, nombre);
    }

    @Override
    public boolean MostrarProblem() {
        Random rand = new Random();
        int cantidad =  1 + this.nivel;
        int solucion = 1;
        int auxm,auxrs,solucion2;
        boolean b;
        String signo = "";
        this.problemasMa = "";
        for (int i = 0; i < cantidad; i++){
            auxm = rand.nextInt(VALOR_MAXM-VALOR_MINM+1)+VALOR_MINM;
            if (i == 0){
                this.problemasMa = this.problemasMa + Integer.toString(auxm) + " x ";
                solucion = solucion * auxm;
            }
            else if (i == 1){
                this.problemasMa = this.problemasMa + Integer.toString(auxm);
                solucion = solucion * auxm;
            }      
            else if (i == 2){
                b = rand.nextBoolean();
                auxrs = rand.nextInt(VALOR_MAXR-VALOR_MINR+1)+VALOR_MINR;
                if (b == true){
                    signo = " + ";
                    solucion = solucion + auxrs;
                }else{
                    signo = " - ";
                    solucion = solucion - auxrs;
                }
                this.problemasMa = this.problemasMa + signo + Integer.toString(auxrs);
            } else if(i == 3){
                this.problemasMa = "(" + this.problemasMa + ")" + " x " + Integer.toString(auxm);
                solucion = solucion * auxm;
            } else if (i== 4){
                b = rand.nextBoolean();
                auxrs = rand.nextInt(VALOR_MAXR-VALOR_MINR+1)+VALOR_MINR;
                if (b == true){
                    signo = " + ";
                    solucion = solucion + auxrs;
                }else{
                    signo = " - ";
                    solucion = solucion - auxrs;
                }
                this.problemasMa = "(" + this.problemasMa + ")" + signo + Integer.toString(auxrs);
            } else if (i==5){
                do{
                    auxm = rand.nextInt(VALOR_MAXM-VALOR_MINM+1)+VALOR_MINM;
                    solucion2 = solucion;
                }while(solucion2 % auxm != 0);
                this.problemasMa = "[" + this.problemasMa + "]" + "/" + auxm;
                solucion = solucion / auxm;
            }
        }
        System.out.println("La respuesta de " + this.problemasMa + " es: ");
        Scanner sc = new Scanner(System.in);
        int respuesta = sc.nextInt();
        if (respuesta == solucion){
            System.out.println("Respuesta correcta! :)");
            this.correcto++;
            return true;
        }else{
            System.out.println("Respuesta incorrecta :(");
            this.incorrecto++;
            return false;
        }
    }
    
}
