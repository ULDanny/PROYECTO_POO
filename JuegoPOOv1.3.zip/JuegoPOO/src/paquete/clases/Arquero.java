/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paquete.clases;

import java.util.Random;
import java.util.Scanner;


public class Arquero extends Aliado{
    public Arquero(int nivel, String nombre) {
    super(nivel, nombre);
  }

  @Override
  public boolean MostrarProblem() {
    Random rand = new Random();
    int solucion = 1;
    int aux;
    this.problemasMa ="";
    aux = rand.nextInt(VALOR_MAXR-VALOR_MINR+1)+VALOR_MINR;
    solucion = aux;
    this.problemasMa = this.problemasMa +aux +"/";
    do{
        aux = rand.nextInt(VALOR_MAXM-VALOR_MINM+1)+VALOR_MINM;
    }while(solucion%aux!=0 || solucion/aux == 1);
    solucion = solucion/aux;
    this.problemasMa = this.problemasMa + aux;
    if(this.nivel >=2){
        aux = rand.nextInt(VALOR_MAXR-VALOR_MINR+1)+VALOR_MINR;
        solucion = solucion + aux;
        this.problemasMa = this.problemasMa +"+"+ aux;
    }if(this.nivel >=3){
        do{
           aux = rand.nextInt(VALOR_MAXM-VALOR_MINM+1)+VALOR_MINM;
        }while(solucion%aux!=0);
        solucion = solucion/aux;
        this.problemasMa = "("+this.problemasMa+")/"+aux;
    }if(this.nivel >=4){
        aux = rand.nextInt(VALOR_MAXR-VALOR_MINR+1)+VALOR_MINR;
        solucion = solucion + aux;
        this.problemasMa = "("+this.problemasMa+")+"+ aux;
    }if(this.nivel ==5){
        do{
            aux = rand.nextInt(VALOR_MAXM-VALOR_MINM+1)+VALOR_MINM;
        }while(solucion%aux!=0);
      solucion = solucion/aux;
      this.problemasMa = "("+this.problemasMa+")/"+aux;
    }
    System.out.println("La respuesta de " + this.problemasMa + " es: ");
    Scanner sc = new Scanner(System.in);
    int respuesta = sc.nextInt();
    if (respuesta == solucion){
        System.out.println("Respuesta correcta! :)");
        return true;
    }else{
        System.out.println("Respuesta incorrecta :(");
        return false;
    }
  }
}
