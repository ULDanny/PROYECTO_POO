/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paquete.clases;

import java.util.Random;


public abstract class Aliado extends Personaje{
    protected String problemasMa;
    protected int exp, expTotal,  correcto, incorrecto, contador,VALOR_MINR,VALOR_MAXR,VALOR_MINM, VALOR_MAXM;
    

    public Aliado(int nivel, String nombre) {
        super(nivel, nombre);
        this.contador = 0;
        VALOR_MINR = 10;
        VALOR_MAXR = 100;
        VALOR_MINM = 1;
        VALOR_MAXM = 10;
    }

    public String getProblemasMa() {
        return problemasMa;
    }

    public void setProblemasMa(String problemasMa) {
        this.problemasMa = problemasMa;
    }

    public int getExp() {
        return exp;
    }

    public void setExp(int exp) {
        this.exp = exp;
    }

    public int getExpTotal() {
        return expTotal;
    }

    public void setExpTotal(int expTotal) {
        this.expTotal = expTotal;
    }

    public int getCorrecto() {
        return correcto;
    }

    public void setCorrecto(int correcto) {
        this.correcto = correcto;
    }

    public int getIncorrecto() {
        return incorrecto;
    }

    public void setIncorrecto(int incorrecto) {
        this.incorrecto = incorrecto;
    }

    public int getContador() {
        return contador;
    }

    public void setContador(int contador) {
        this.contador = contador;
    }
  
    public abstract boolean MostrarProblem();

    public void CalcExp(){
        this.exp = this.correcto *10 - this.incorrecto*5;
        if(this.exp <5){
        this.exp =5;
        }
        this.expTotal+=exp;
    }
    public void CalcNivel(){
        while(this.expTotal>=(30+this.nivel*10)){
            this.expTotal = this.expTotal-(30+this.nivel*10);
            this.nivel++;
        }
    }
    
    @Override
    public void Ataque() {
        if (MostrarProblem()){
            if(this.contador < 2){
                this.ataque = 10;
                this.contador++;
                System.out.println("Tu ataque acerto");
            }else if (this.contador == 2){
                Random rand = new Random();
                float critico = rand.nextFloat()+1;
                this.ataque = (int) (10 * critico);
                this.contador = 0;
                System.out.println("¡Wow, tu ataque fue critico!");
            }
        }else{
            this.contador = 0;
            this.ataque = 0;
            System.out.println("Tu ataque fallo");
        }   
    }
}
