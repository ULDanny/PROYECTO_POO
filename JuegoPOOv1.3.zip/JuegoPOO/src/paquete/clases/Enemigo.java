/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paquete.clases;

import java.util.Random;


public class Enemigo extends Personaje{

    public Enemigo(int nivel, String nombre) {
        super(nivel, nombre);
    }

    @Override
    public void Ataque() {
        Random rand = new Random();
        if(rand.nextBoolean()){
            this.ataque = rand.nextInt(13-8+1)+8;
        }else{
            this.ataque = 0;
        }
    }
    
}
